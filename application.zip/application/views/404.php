
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
	
<!-- Mirrored from p.w3layouts.com/demos/ohh/web/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 25 Apr 2016 12:10:20 GMT -->
<head>
		<title>0hh Website Template | Home :: W3layouts</title>
		<meta name="keywords" content="404 iphone web template, Android web template, Smartphone web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
		<link href="<?php echo base_url('assets/web/404/css/style.css');?>" rel="stylesheet" type="text/css"  media="all" />
	</head>
	<body>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../../../../www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-30027142-1', 'w3layouts.com');
  ga('send', 'pageview');
</script>
<script async type='text/javascript' src='../../../../cdn.fancybar.net/ac/fancybar6a2f.js?zoneid=1502&amp;serve=C6ADVKE&amp;placement=w3layouts' id='_fancybar_js'></script>


		<!--start-wrap--->
		<div class="wrap">
			<!---start-header---->
				<div class="header">
					<div class="logo">
						<h1><a href="#">Ohh</a></h1>
					</div>
				</div>
				<!---728x90--->
<div style="text-align: center;"><script async src="../../../../pagead2.googlesyndication.com/pagead/js/f.txt"></script>
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-9153409599391170"
     data-ad-slot="6850850687"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></div>
			<!---End-header---->
			<!--start-content------>
			<div class="content">
				<img src="<?php echo base_url('assets/web/404/images/error-img.png');?>" title="error" />
				<!---728x90--->
<div style="text-align: center;"><script async src="../../../../pagead2.googlesyndication.com/pagead/js/f.txt"></script>
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-9153409599391170"
     data-ad-slot="6850850687"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></div>
				<p><span><label>O</label>hh.....</span>You Requested the page that is no longer There.</p>
				
				<a href="#">Back To Home</a>
				<!---728x90--->
<div style="text-align: center;"><script async src="../../../../pagead2.googlesyndication.com/pagead/js/f.txt"></script>
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-9153409599391170"
     data-ad-slot="6850850687"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></div>
				<div class="copy-right">
					<p>&copy; 2013 Ohh. All Rights Reserved | Design by <a href="http://w3layouts.com/">W3Layouts</a></p>
				</div>
   			</div>
			<!--End-Cotent------>
		</div>
		<!--End-wrap--->
	</body>

<!-- Mirrored from p.w3layouts.com/demos/ohh/web/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 25 Apr 2016 12:10:24 GMT -->
</html>

