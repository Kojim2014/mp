<div id="daftar_kelas">
  <div class="title_content"><p> Kelas yang di ikuti </p></div>
  <div class="content content_profil">
	<li class="cover-wrapper">
	  <a href="../../kelas/video/Belajar-Codeigniter-untuk-pemula.html">
		<div class="bg_transparent"></div>
		<p>Belajar Codeigniter untuk pemula</p>
		<img src="<?php echo base_url('assets/asset/cover/codeigniter.png');?>" alt="" />
	  </a>
	</li>
	<div class="clear"></div>
  </div>
</div>